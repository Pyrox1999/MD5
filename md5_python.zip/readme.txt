This app converts a normal text into MD5

Music by haruta